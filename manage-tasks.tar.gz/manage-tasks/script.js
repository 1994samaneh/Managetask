// Declare Variables
//Elements with no Id
const form = document.getElementById('myForm');
const ul = document.querySelector('ul');
const btn = document.getElementById('alaki');
const btnSaveTask =document.getElementById('saveTask');
const btnDeleteText =document.getElementById('deleteText');


//Elements with Id
const input = document.getElementById('task');

let allTasks = localStorage.getItem('tasks') ? JSON.parse(localStorage.getItem('tasks')) : [];

localStorage.setItem('tasks', JSON.stringify(allTasks));
const data = JSON.parse(localStorage.getItem('tasks'));

 taskList = (task) => {
    const li = document.createElement("li");
    let deletebtn = document.createElement("BUTTON");
    let activebtn = document.createElement("BUTTON");
    let span = document.createElement("span");
    deletebtn.setAttribute("type", "button");
    deletebtn.setAttribute("id", "deleteButton");
    deletebtn.setAttribute("key", "deleteButton");
    deletebtn.setAttribute("class", "fa fa-trash");

    activebtn.setAttribute("type", "button");
    activebtn.setAttribute("id", "activeButton");
    activebtn.setAttribute("key", "activeButton");
    activebtn.setAttribute("class", "fa fa-check-circle");
    span.textContent = task ;
    li.appendChild(span);
    li.appendChild(activebtn);
    li.appendChild(deletebtn);

    ul.appendChild(li);

    deletebtn.addEventListener('click',function (e) {
        e.preventDefault();
        ul.removeChild(li);
    });
    activebtn.addEventListener('click',function (e) {
        e.preventDefault();
        li.setAttribute("class", "activeLi");
    })
}


input.addEventListener('keypress', function(e) {
    if (event.keyCode === 13) {
        event.preventDefault();
    }
});

btnDeleteText.addEventListener('click', function (e) {
    e.preventDefault();
    input.value = '';
});


btnSaveTask.addEventListener('click', function (e) {
    e.preventDefault();
    allTasks.push(input.value);
    localStorage.setItem('tasks', JSON.stringify(allTasks));
    taskList(input.value);
    input.value = '';
});

form.addEventListener('submit', function (e) {
    e.preventDefault();
});

data.forEach(task => {
    taskList(task);
});

btn.addEventListener('click', function (){
    localStorage.clear();
    while(ul.firstChild){
        ul.removeChild(ul.firstChild);
    }
});

