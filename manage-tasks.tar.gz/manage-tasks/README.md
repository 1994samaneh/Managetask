![](https://cloud.githubusercontent.com/assets/110953/7877439/6a69d03e-0590-11e5-9fac-c614246606de.png)
## Codelab: Building your first ES2015 app

This repo contains the initial and final code for the [Building your first ES2015 app](http://www.code-labs.io/codelabs/chrome-es2015) codelab. (Not published yet! Working on it!)

